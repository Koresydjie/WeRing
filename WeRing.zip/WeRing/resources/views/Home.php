<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <style type="text/css">
        .navbar{
            background-color:#B0B0B0;
            height: 80px;
            text-align: center;
        }
        .nav-items{
            display: flex;
            width: 100%;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;

        }
        li {
            float: left;
        }
        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 16px;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="navbar";>
    <div class="col-md-2" style="height: 80px">logo</div>
    <div class="col-md-9" style="height: 80px">
        <ul>
            <li class="nav-link"><a href="#home">Home</a></li>
            <li class="nav-link"><a href="#news">News</a></li>
            <li class="nav-link"><a href="#contact">Contact</a></li>
            <li class="nav-link"><a href="#about">About</a></li>
        </ul>

    </div>
    <div class="col-md-1" style="height: 80px; ">
    <ul>
        <li>
            <a href="/login" class="nav-link"> <button type="button" class="btn btn-success">Login</button></a>
        </li>
    </ul>
    </div>
</div>
</body>
</html>
