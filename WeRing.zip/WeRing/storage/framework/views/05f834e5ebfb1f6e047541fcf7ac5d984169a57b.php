
<?php $__env->startSection('container'); ?>

    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body>
<div class="hero">
    <div class="form-box">
        <div class="button-box">
            <div id= "btn"></div>
            <button type="button" class="toggle-btn" onclick="Login()">Login</button>
            <button type="button" class="toggle-btn" onclick="Register()">Register</button>
        </div>
        <div class="social-icons">
            <a href="https://www.facebook.com/"><img src="asset/imageedit_2_8498791683.png" ></a>
            <a href="https://www.google.com/account/about/"><img src="asset/gp.png" ></a>
            <a href="https://twitter.com/?lang=en"><img src="asset/tp.png" ></a>
        </div>
        <form id="Login" class="input-group">
            <input type="text", class="input-field" placeholder="User Id" required>
            <input type="text", class="input-field" placeholder="Enter Password" required>
            <input type="checkbox" class="check-box"><span>Remember Me</span>
            <button type="submit" class="submit-btn" >Login</button>
        </form>
        <form id="Register" class="input-group">
            <input type="text", class="input-field" placeholder="User Id" required>
            <input type="email", class="input-field" placeholder="Input your Email" required>
            <input type="password", class="input-field" placeholder="Enter Password" required>
            <input type="password", class="input-field" placeholder="Confirm Password" required>
            <input type="checkbox" class="check-box"><span>Terms & Condition</span>
            <button type="submit" class="submit-btn">Register</button>
        </form>
    </div>

</div>

<script>
    var x=document.getElementById("Login");
    var y=document.getElementById("Register");
    var z=document.getElementById("btn");

    function Register(){
        x.style.left = "-400px";
        y.style.left = "50px"
        z.style.left = "110px"
    }
    function Login(){
        x.style.left = "50px";
        y.style.left = "450px"
        z.style.left = "0px"
    }
</script>





</body>
</html>

<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\WeRing\resources\views/login/login.blade.php ENDPATH**/ ?>